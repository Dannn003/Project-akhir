<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
    // Memuat: resources/views/backend/v_home/home.blade.php
    return view('backend.v_home.home',[
        'judul'=>'Halaman Home'
    ]);
    }
}
