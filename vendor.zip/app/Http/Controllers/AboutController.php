<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutController extends Controller
{
    public function index()
    {
    // Memuat: resources/views/backend/v_about/about.blade.php
    return view('backend.v_about.about',[
                    'judul'=>'Halaman About'
                ]);
    }
}
