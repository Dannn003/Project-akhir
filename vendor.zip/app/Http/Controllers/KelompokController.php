<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KelompokController extends Controller
{
    public function index()
    {
    // Memuat: resources/views/backend/v_kelompok/kelompok.blade.php
    return view('backend.v_kelompok.kelompok',[
        'judul'=>'Halaman Kelompok'
    ]); 
    }
}
