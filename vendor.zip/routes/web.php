<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BerandaController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\KelompokController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    //return view('welcome');
return redirect()->route('Home');
});
Route::get('index',[BerandaController::class, 'index'])->name('Beranda');
Route::get('about', [AboutController::class, 'index'])->name('About');
Route::get('home', [HomeController::class, 'index'])->name('Home');
Route::get('kelompok', [KelompokController::class, 'index'])->name('Kelompok');